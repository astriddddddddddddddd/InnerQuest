from flask import Flask, render_template
import textwrap
#import google.generativeai as genai  #gemini
from openai import OpenAI             #Open AI
import usersQuestions as userq

#genai.configure(api_key='AIzaSyDMG6KRWhCJO1yDk1okerJcBPm4pwlCwy0')  #gemini
client = OpenAI(api_key='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') #OPENAI

userq.add_user("user1")
cagry_prompt = {}
cagry_prompt["Bad"] = "Bored: Feeling indifferent or apathetic due to a lack of interest or stimulation." \
                  "Busy: Feeling pressured or rushed due to having many tasks or commitments to manage." \
                  "Stressed: Feeling overwhelmed or out of control due to excessive demands or challenges." \
                  "Tired: Feeling sleepy or unfocused due to a lack of rest or mental fatigue." 
                  
cagry_prompt["Surprised"] = "Startled: Feeling suddenly surprised or alarmed due to an unexpected event." \
                  "Confused: Feeling unable to think clearly or understand something." \
                  "Amazed: Feeling overwhelming surprise or wonder." \
                  "Excited: Feeling enthusiastic and eager about something."
cagry_prompt["Happy"] = "Playful: Feeling light-hearted and full of fun often involving spontaneous and lively behavior." \
                  "Content: Feeling satisfied and at ease with one's situation." \
                  "Interested: Feeling curiosity and attentiveness towards something or someone." \
                  "Proud: Feeling deep pleasure or satisfaction as a result of one's own achievements, qualities or possessions." \
                  "Accepted: Feeling recognized and valued by others often contributing to a sense of belonging." \
                  "Powerful: Feeling strong and capable often with the ability to influence or control situations." \
                  "Peaceful: Feeling calm and serene free from disturbance or conflict." \
                  "Trusting: Feeling confident in the reliability, truth or ability of someone or something." \
                  "Optimistic: Feeling hopeful and confident about the future."                  
cagry_prompt["Sad"] =  "Lonely: Feeling isolated and lacking companionship." \
                  "Vulnerable: Feeling susceptible to harm or emotional injury." \
                  "Despair: Feeling a complete loss of hope or confidence." \
                  "Guilty: Feeling responsible for wrongdoing or offense." \
                  "Depressed: Feeling of severe despondency and dejection." \
                  "Hurt: Feeling emotional pain or distress."
cagry_prompt["Disgusted"] = "Disapproving: Expressing or feeling negative judgment or disapproval towards someone or something." \
                  "Disappointed: Feeling let down or disillusioned by unmet expectations or outcomes." \
                  "Awful: Extremely unpleasant or disagreeable; causing a feeling of dismay or horror." \
                  "Repelled: Feeling a strong aversion or disgust towards something or someone."
cagry_prompt["Angry"] = "Let-down: Feeling disappointed or betrayed by someone or something." \
                  "Humiliated: Feeling embarrassed or ashamed by being belittled or degraded." \
                  "Bitter: Feeling resentful or unhappy due to unfair treatment or disappointment." \
                  "Mad: Feeling angry or upset." \
                  "Aggressive: Feeling hostile or confrontational." \
                  "Frustrated: Feeling annoyed or discouraged due to obstacles or lack of progress." \
                  "Distant: Feeling emotionally or physically separated from others." \
                  "Critical: Expressing disapproval or judgment towards someone or something."
cagry_prompt["Fearful"] = "Scared: Feeling fear or apprehension about something." \
                  "Anxious: Feeling worried, nervous or uneasy about something with an uncertain outcome." \
                  "Insecure: Feeling uncertain or lacking confidence in oneself or one's abilities." \
                  "Weak: Lacking in strength or power either physically or emotionally." \
                  "Rejected: Feeling dismissed or excluded by others." \
                  "Threatened: Feeling in danger or at risk of harm or loss."
cagry_html = {}
cagry_html["Bad"] = "bad.html"
cagry_html["Surprised"] = "surprised.html"
cagry_html["Happy"] = "happy.html"
cagry_html["Sad"] = "sad.html" 
cagry_html["Disgusted"] = "disgusted.html"
cagry_html["Angry"] = "angry.html"
cagry_html["Fearful"] = "fearful.html"  

cagry_sub = {}

# bad_array
cagry_sub["Bad"] = {}
cagry_sub["Bad"]["Bored"] = ["無聊", "由於缺乏興趣或刺激而感到冷漠或無動於衷", "bored.png"]
cagry_sub["Bad"]["Busy"] = ["忙碌", "由於有許多任務或承諾需要管理而感到壓力或匆忙", "busy.png"]
cagry_sub["Bad"]["Stressed"] = ["壓力", "由於過度的需求或挑戰而感到不知所措或失控", "stressed.png"]
cagry_sub["Bad"]["Tired"] = ["疲倦", "由於缺乏休息或精神疲勞而感到困倦或無法集中注意力", "tired.png"]

# happy_array
cagry_sub["Happy"] = {}
cagry_sub["Happy"]["Playful"] = ["玩樂", "感到輕鬆愉快，充滿樂趣，通常涉及自發和活潑的行為", "playful.png"]
cagry_sub["Happy"]["Content"] = ["滿足", "對自己的處境感到滿意和安心", "content.png"]
cagry_sub["Happy"]["Interested"] = ["感興趣", "對某事或某人感到好奇和專注", "interested.png"]
cagry_sub["Happy"]["Proud"] = ["自豪", "由於自己的成就,品質或財產而感到深深的愉悅或滿足", "proud.png"]
cagry_sub["Happy"]["Accepted"] = ["被接受", "感到被他人認可和重視，通常會產生一種歸屬感", "accepted.png"]
cagry_sub["Happy"]["Powerful"] = ["強大", "感到強壯和有能力，通常有影響或控制局面的能力", "powerful.png"]
cagry_sub["Happy"]["Peaceful"] = ["平靜", "感到平和和寧靜，沒有干擾或衝突", "peaceful.png"]
cagry_sub["Happy"]["Trusting"] = ["信任", "對某人或某物的可靠性、真實性或能力充滿信心", "trusting.png"]
cagry_sub["Happy"]["Optimistic"] = ["樂觀", "對未來感到希望和信心", "optimistic.png"]

# surprised_array
cagry_sub["Surprised"] = {}
cagry_sub["Surprised"]["Startled"] = ["驚嚇", "由於意外事件感到突然的驚訝或驚慌", "startled.png"]
cagry_sub["Surprised"]["Confused"] = ["困惑", "感到無法清晰思考或理解某事", "confused.png"]
cagry_sub["Surprised"]["Amazed"] = ["驚奇", "感到難以置信的驚訝或奇蹟", "amazed.png"]
cagry_sub["Surprised"]["Excited"] = ["興奮", "對某事感到熱情和渴望", "excited.png"]

# fearful_array
cagry_sub["Fearful"] = {}
cagry_sub["Fearful"]["Scared"] = ["害怕", "對某事感到恐懼或擔憂", "scared.png"]
cagry_sub["Fearful"]["Anxious"] = ["焦慮", "對某事感到擔憂，緊張或不安，結果不確定", "anxious.png"]
cagry_sub["Fearful"]["Insecure"] = ["不安", "對自己或自己的能力感到不確定或缺乏信心", "insecure.png"]
cagry_sub["Fearful"]["Weak"] = ["虛弱", "在身體上或情感上缺乏力量", "weak.png"]
cagry_sub["Fearful"]["Rejected"] = ["被拒絕", "感到被他人拒絕或排斥", "rejected.png"]
cagry_sub["Fearful"]["Threatened"] = ["受到威脅", "感到處於危險或受到傷害或損失的風險", "threatened.png"]

# disgusted_array
cagry_sub["Disgusted"] = {}
cagry_sub["Disgusted"]["Disapproving"] = ["不贊成", "對某人或某事表達或感到負面的評價或不贊同", "disapproving.png"]
cagry_sub["Disgusted"]["Disappointed"] = ["失望", "由於未達到期望或結果而感到失落或幻滅", "disappointed.png"]
cagry_sub["Disgusted"]["Awful"] = ["可怕", "極其不愉快或令人不快；引起沮喪或恐懼的感覺", "awful.png"]
cagry_sub["Disgusted"]["Repelled"] = ["厭惡", "對某事或某人感到強烈的反感或厭惡", "repelled.png"]

# angry_array
cagry_sub["Angry"] = {}
cagry_sub["Angry"]["Let-down"] = ["失望", "感到被某人或某事辜負或背叛", "let-down.png"]
cagry_sub["Angry"]["Humiliated"] = ["羞辱", "因被貶低或侮辱而感到尷尬或羞愧", "humiliated.png"]
cagry_sub["Angry"]["Bitter"] = ["痛苦", "由於不公平的待遇或失望而感到怨恨或不開心", "bitter.png"]
cagry_sub["Angry"]["Mad"] = ["生氣", "感到憤怒或不快", "mad.png"]
cagry_sub["Angry"]["Aggressive"] = ["好鬥", "感到敵對或對抗", "aggressive.png"]
cagry_sub["Angry"]["Frustrated"] = ["煩躁", "由於障礙或缺乏進展而感到惱怒或氣餒", "frustrated.png"]
cagry_sub["Angry"]["Distant"] = ["疏遠", "感到與他人在情感上或身體上分離", "distant.png"]
cagry_sub["Angry"]["Critical"] = ["批評", "對某人或某事表達不滿或批評", "critical.png"]

# sad_array
cagry_sub["Sad"] = {}
cagry_sub["Sad"]["Lonely"] = ["孤獨", "感到孤立和缺乏陪伴", "lonely.png"]
cagry_sub["Sad"]["Vulnerable"] = ["脆弱", "感到易受傷害或情感傷害", "vulnerable.png"]
cagry_sub["Sad"]["Despair"] = ["絕望", "感到完全失去希望或信心", "despair.png"]
cagry_sub["Sad"]["Guilty"] = ["內疚", "對自己的過錯或冒犯感到負責", "guilty.png"]
cagry_sub["Sad"]["Depressed"] = ["抑鬱", "感到極度的沮喪和絕望", "depressed.png"]
cagry_sub["Sad"]["Hurt"] = ["受傷", "感到情感上的痛苦或困擾", "hurt.png"]


''' #Gemini
def get_response(prompt):
    model = genai.GenerativeModel('gemini-1.5-flash')
    response = model.generate_content(prompt)
    return response.text 
'''
#OpenAI
def get_response(prompt):
    response = client.chat.completions.create(
#      model="gpt-4",    
      model="gpt-3.5-turbo",
      messages=[
        {"role": "user", "content": prompt},
      ]
    )
    #print(response.json())
    #print(response.choices[0].message.content)
    return response.choices[0].message.content

app = Flask(__name__)

@app.route('/')
def home():
     return render_template('index.html')

@app.route('/InnerQuestion/<cagry>')
def innerQuest(cagry):
     print("category:"+cagry)
     prompt=  "Create one yes no question without actually using the words in the following description to help to identify which of the following categories they fall in." + cagry_prompt[cagry] + "; Create and display just the questions by using traditional Chinese." 
     try:
        question = get_response(prompt)
     except Exception as e:
        print(f"API 調用出錯: {e}")
        print("Prompt:")
        print(prompt)
        question="系統有誤請SKIP!"
     print(question)
     userq.clear_user_questions("user1")
     userq.add_user_question("user1",question)
     return render_template('InnerQuest Qs.html', question=question,category=cagry)
     
@app.route('/InnerQuestion/<cagry>/<resp>')
def innerQuest_2(cagry,resp):
    print("category:"+cagry+"  resp:"+resp)
    if resp == "yes":
        userq.add_user_question("user1","Yes\n")
    elif resp == "no":
        userq.add_user_question("user1","No\n")
    elif resp == "skip":
        userq.delete_last_user_question("user1")
    elif resp == "result":
        userq.delete_last_user_question("user1")
        prompt= userq.return_user_questions("user1") + "According to the responses above, which category is the person in following? Without add additional wordings, just respone the word before ':' from following categories." + cagry_prompt[cagry]
        result=get_response(prompt)
        result=result.split(' ')[0]
        result=result.split(':')[0]
        print("result:")
        print(result)
        if result not in cagry_sub[cagry]:
            return ("The result is not the the categories :" + result)
        return render_template(cagry_html[cagry], mood=cagry_sub[cagry][result][0],desc=cagry_sub[cagry][result][1],imgName=cagry_sub[cagry][result][2]) 
    if userq.get_user_question_count("user1") >= 20:                                                                                                                        
        prompt= userq.return_user_questions("user1") + "According to the responses above, which category is the person in following? Without add additional wordings, just respone the word before ':' from following categories." + cagry_prompt[cagry]
        result=get_response(prompt)
        result=result.split(' ')[0]
        result=result.split(':')[0]
        print("result:")
        print(result)
        if result not in cagry_sub[cagry]:
            return ("The result is not the the categories :" + result)
        return render_template(cagry_html[cagry], mood=cagry_sub[cagry][result][0],desc=cagry_sub[cagry][result][1],imgName=cagry_sub[cagry][result][2]) 
    prompt= userq.return_user_questions("user1")+ "According to the responses above, can you make one more yes-no question that will lead to more accurate analysis of the category the person falls in? Without any additional wordings, just the question. Create and display the questions by using traditional Chinese." 
    try:
        question = get_response(prompt)   
    except Exception as e:
        print(f"API 調用出錯: {e}")
        print("Prompt:")
        print(prompt)
        question="系統有誤請SKIP!"
    print(question)
    userq.add_user_question("user1",question)
#    number=str(int(number)+1)
    return render_template('InnerQuest Qs.html', question=question,category=cagry)     
     
if __name__ == '__main__':
    app.run('0.0.0.0', 8000)
